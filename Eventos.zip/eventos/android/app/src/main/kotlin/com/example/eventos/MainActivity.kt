package com.example.eventos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
