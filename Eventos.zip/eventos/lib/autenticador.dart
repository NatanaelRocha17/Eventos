import 'package:google_sign_in/google_sign_in.dart';

class Usuario {
  String? _nome = "";
  String? get nome => _nome;
  set nome(String? nome) {
    _nome = nome;
  }

  String _email = "";
  String get email => _email;
  set email(String email) {
    _email = email;
  }

  Usuario(String? nome, String email) {
    _nome = nome;
    _email = email;
  }
}

class Autenticador {
  // Variável estática para armazenar o usuário logado
  static Usuario? usuarioAtual;

  // Login do usuário
  static Future<Usuario> login() async {
    final gUser = await GoogleSignIn().signIn();
    if (gUser != null) {
      final usuario = Usuario(gUser.displayName, gUser.email);
      usuarioAtual = usuario; // Armazena o usuário logado
      return usuario;
    } else {
      throw Exception("Falha no login do Google.");
    }
  }



  // Logout do usuário
  static Future<void> logout() async {
    await GoogleSignIn().signOut();
    usuarioAtual = null; // Remove o usuário logado
  }
}
