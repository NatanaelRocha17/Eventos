import 'package:flutter/material.dart';
import 'package:eventos/autenticador.dart';

enum Situacao { mostrandoEventos, mostrandoDetalhes }

class Estado extends ChangeNotifier {
  Situacao _situacao = Situacao.mostrandoEventos;
  double _altura = 0, _largura = 0;
  double get altura => _altura;
  double get largura => _largura;

  late int _idEvento;
  int get idEvento => _idEvento;

  Usuario? _usuario;
  Usuario? get usuario => _usuario;

  // Método para definir as dimensões da tela
  void setDimensoes(double altura, double largura) {
    _altura = altura;
    _largura = largura;
    notifyListeners();
  }

  // Métodos para gerenciar a exibição dos eventos
  void mostrarEventos() {
    _situacao = Situacao.mostrandoEventos;
    notifyListeners();
  }

  bool mostrandoEventos() {
    return _situacao == Situacao.mostrandoEventos;
  }

  void mostrarDetalhes(int idEvento) {
    _situacao = Situacao.mostrandoDetalhes;
    _idEvento = idEvento;
    notifyListeners();
  }

  bool mostrandoDetalhes() {
    return _situacao == Situacao.mostrandoDetalhes;
  }

  // Método de login
  Future<void> login() async {
    final usuario = await Autenticador.login();  // Chama o autenticador para fazer o login
    if (usuario != null) {
      _usuario = usuario;  // Define o usuário
      notifyListeners();  // Notifica os ouvintes
    }
  }

  // Método de logoff
  Future<void> logoff() async {
    _usuario = null;  // Limpa as informações do usuário
    await Autenticador.logout();  // Chama o logout do autenticador
    notifyListeners();  // Notifica os ouvintes
  }
}

late Estado estadoApp; // Variável global
